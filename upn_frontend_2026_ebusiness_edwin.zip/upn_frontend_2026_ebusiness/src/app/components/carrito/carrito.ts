import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MenuComponent } from '../../menu/menu.component';
import { CarritoService } from '../../services/carrito-service';

@Component({
  selector: 'app-carrito',
  standalone: true,
  imports: [CommonModule, MenuComponent, RouterLink],
  templateUrl: './carrito.html',
  styleUrl: './carrito.css',
})
export class Carrito {

  constructor(public carritoService: CarritoService) { }

}
