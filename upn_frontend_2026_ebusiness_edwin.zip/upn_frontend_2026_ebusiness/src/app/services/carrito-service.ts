import { Injectable } from '@angular/core';
import { Producto } from '../models/producto.model';
import { ItemCarrito } from '../models/item-carrito.model';

const CLAVE_CARRITO = 'carrito';

@Injectable({
  providedIn: 'root',
})
export class CarritoService {

  items: ItemCarrito[] = [];

  constructor() {
    try {
      this.items = JSON.parse(localStorage.getItem(CLAVE_CARRITO) || '[]');
    } catch {
      this.items = [];
    }
  }

  agregar(producto: Producto, cantidad: number): void {
    const item = this.items.find(x => x.producto.id === producto.id);
    if (item) {
      item.cantidad += cantidad;
    } else {
      this.items.push({ producto, cantidad });
    }
    this.guardar();
  }

  eliminar(idProducto: number): void {
    this.items = this.items.filter(x => x.producto.id !== idProducto);
    this.guardar();
  }

  totalUnidades(): number {
    return this.items.reduce((suma, x) => suma + x.cantidad, 0);
  }

  total(): number {
    return this.items.reduce((suma, x) => suma + x.cantidad * (x.producto.price ?? 0), 0);
  }

  private guardar(): void {
    localStorage.setItem(CLAVE_CARRITO, JSON.stringify(this.items));
  }
}
