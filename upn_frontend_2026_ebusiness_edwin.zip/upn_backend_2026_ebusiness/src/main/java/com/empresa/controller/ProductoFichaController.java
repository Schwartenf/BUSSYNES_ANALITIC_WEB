package com.empresa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.empresa.dto.ProductoFichaDTO;
import com.empresa.service.ProductoFichaService;
import com.empresa.util.AppSettings;

@RestController
@RequestMapping("/url/productoFicha")
@CrossOrigin(origins = AppSettings.URL_CROSS_ORIGIN)
public class ProductoFichaController {

    @Autowired
    private ProductoFichaService service;

    // Cualquier visitante puede consultar la ficha de un producto
    @GetMapping("/{idProducto}")
    public ResponseEntity<?> obtenerFicha(@PathVariable int idProducto) {

        ProductoFichaDTO ficha = service.obtenerFicha(idProducto);

        // 404 si el producto todavía no tiene ficha registrada
        if (ficha == null) {
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(ficha);
    }
}
