package com.empresa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.empresa.entity.Categoria;
import com.empresa.service.CategoriaService;
import com.empresa.util.AppSettings;

@RestController
@RequestMapping("/url/categoria")
@CrossOrigin(origins = AppSettings.URL_CROSS_ORIGIN)
public class CategoriaController {

    @Autowired
    private CategoriaService service;

    // Cualquier visitante puede listar las categorías
    @GetMapping
    public ResponseEntity<List<Categoria>> listaCategoria() {
        return ResponseEntity.ok(service.listaTodos());
    }
}
