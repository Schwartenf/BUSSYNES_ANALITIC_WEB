package com.empresa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.empresa.entity.Producto;
import com.empresa.service.CategoriaService;
import com.empresa.service.ProductoService;
import com.empresa.util.AppSettings;

@RestController
@RequestMapping("/url/producto")
@CrossOrigin(origins = AppSettings.URL_CROSS_ORIGIN)
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @Autowired
    private CategoriaService categoriaService;

    // Búsqueda por categoría: cualquier visitante puede consultarla
    @GetMapping("/categoria/{idCategoria}")
    public ResponseEntity<?> listaPorCategoria(@PathVariable int idCategoria) {

        // 404 si la categoría no existe
        if (!categoriaService.existe(idCategoria)) {
            return ResponseEntity.notFound().build();
        }

        // 200 con lista vacía si la categoría existe pero no tiene productos
        List<Producto> lista = productoService.listaPorCategoria(idCategoria);
        return ResponseEntity.ok(lista);
    }
}
