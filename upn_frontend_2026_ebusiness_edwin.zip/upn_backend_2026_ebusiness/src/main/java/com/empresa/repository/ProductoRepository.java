package com.empresa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.empresa.entity.Producto;

public interface ProductoRepository extends JpaRepository<Producto, Integer> {

    // Productos de una categoría, en orden alfabético
    List<Producto> findByIdCategoriaOrderByNombreAsc(int idCategoria);
}
