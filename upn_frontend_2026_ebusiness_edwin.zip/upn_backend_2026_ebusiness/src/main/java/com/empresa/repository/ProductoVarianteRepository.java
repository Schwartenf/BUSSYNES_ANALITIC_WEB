package com.empresa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.empresa.entity.ProductoVariante;

public interface ProductoVarianteRepository
        extends JpaRepository<ProductoVariante, Integer> {

    // Solo variantes activas (estado = 1), en el orden en que se registraron
    // (así las tallas salen S, M, L, XL tal como se insertaron).
    List<ProductoVariante> findByIdProductoAndEstadoOrderByIdVarianteAsc(
            int idProducto, int estado);

}
