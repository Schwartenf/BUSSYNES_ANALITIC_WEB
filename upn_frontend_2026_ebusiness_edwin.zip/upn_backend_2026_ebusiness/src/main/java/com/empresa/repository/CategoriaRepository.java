package com.empresa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.empresa.entity.Categoria;

public interface CategoriaRepository extends JpaRepository<Categoria, Integer> {

    // Categorías en orden alfabético, para llenar el combo de búsqueda
    List<Categoria> findByOrderByDescripcionAsc();
}
