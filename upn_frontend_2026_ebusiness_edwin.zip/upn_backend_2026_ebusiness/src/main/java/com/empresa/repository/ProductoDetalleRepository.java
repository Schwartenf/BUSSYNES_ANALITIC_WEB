package com.empresa.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.empresa.entity.ProductoDetalle;

public interface ProductoDetalleRepository
        extends JpaRepository<ProductoDetalle, Integer> {

    Optional<ProductoDetalle> findByIdProducto(int idProducto);

}
