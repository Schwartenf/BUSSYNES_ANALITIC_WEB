package com.empresa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.empresa.entity.ProductoAtributo;

public interface ProductoAtributoRepository
        extends JpaRepository<ProductoAtributo, Integer> {

    List<ProductoAtributo> findByIdProductoOrderByOrdenAsc(int idProducto);

}
