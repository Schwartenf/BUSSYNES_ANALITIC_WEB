package com.empresa.dto;

import java.util.List;

import com.empresa.entity.ProductoAtributo;
import com.empresa.entity.ProductoDetalle;
import com.empresa.entity.ProductoVariante;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

// Respuesta completa de la ficha de un producto, en una sola llamada.
@Getter
@Setter
@AllArgsConstructor
public class ProductoFichaDTO {

    private ProductoDetalle detalle;

    private List<ProductoAtributo> atributos;

    private List<ProductoVariante> variantes;

}
