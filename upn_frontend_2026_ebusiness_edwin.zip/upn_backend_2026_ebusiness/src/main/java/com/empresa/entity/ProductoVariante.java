package com.empresa.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

// Una combinación vendible de un producto: color + talla, con su SKU y su stock.
// talla es null en los productos que no tienen tallas (por ejemplo, electrónica).
@Getter
@Setter
@Entity
@Table(name = "producto_variante")
public class ProductoVariante {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idVariante;

    private int idProducto;

    private String sku;

    private String color;

    private String talla;

    private int stock;

    private int estado;
}
