package com.empresa.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

// Datos generales de un producto: SKU, condición, marca, modelo y descripción.
// idProducto es el id del producto en FakeStore API.
@Getter
@Setter
@Entity
@Table(name = "producto_detalle")
public class ProductoDetalle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idProductoDetalle;

    private int idProducto;

    private String sku;

    private String condicion;

    private String marca;

    private String modelo;

    private String descripcionGeneral;
}
