package com.empresa.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Getter;
import lombok.Setter;

// Una característica del producto en formato nombre/valor.
// Ejemplo: nombre = "Material de vestuario", valor = "Algodón"
@Getter
@Setter
@Entity
@Table(name = "producto_atributo")
public class ProductoAtributo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idAtributo;

    private int idProducto;

    private String nombre;

    private String valor;

    private int orden;
}
