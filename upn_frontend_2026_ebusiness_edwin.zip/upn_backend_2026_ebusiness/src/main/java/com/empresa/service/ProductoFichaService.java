package com.empresa.service;

import com.empresa.dto.ProductoFichaDTO;

public interface ProductoFichaService {

    // Devuelve la ficha del producto o null si no tiene ficha registrada.
    public ProductoFichaDTO obtenerFicha(int idProducto);

}
