package com.empresa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.empresa.dto.ProductoFichaDTO;
import com.empresa.entity.ProductoAtributo;
import com.empresa.entity.ProductoDetalle;
import com.empresa.entity.ProductoVariante;
import com.empresa.repository.ProductoAtributoRepository;
import com.empresa.repository.ProductoDetalleRepository;
import com.empresa.repository.ProductoVarianteRepository;

@Service
public class ProductoFichaServiceImpl implements ProductoFichaService {

    // Estado de una variante activa
    private static final int ESTADO_ACTIVO = 1;

    @Autowired
    private ProductoDetalleRepository detalleRepository;

    @Autowired
    private ProductoAtributoRepository atributoRepository;

    @Autowired
    private ProductoVarianteRepository varianteRepository;

    @Override
    public ProductoFichaDTO obtenerFicha(int idProducto) {

        Optional<ProductoDetalle> detalle =
                detalleRepository.findByIdProducto(idProducto);

        // Si el producto no tiene ficha, no hay nada que devolver
        if (detalle.isEmpty()) {
            return null;
        }

        List<ProductoAtributo> atributos =
                atributoRepository.findByIdProductoOrderByOrdenAsc(idProducto);

        List<ProductoVariante> variantes =
                varianteRepository.findByIdProductoAndEstadoOrderByIdVarianteAsc(
                        idProducto, ESTADO_ACTIVO);

        return new ProductoFichaDTO(detalle.get(), atributos, variantes);
    }
}
